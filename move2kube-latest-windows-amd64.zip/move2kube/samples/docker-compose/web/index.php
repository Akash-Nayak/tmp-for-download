<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fibonacci</title>
</head>
<body>
    <form action="/fib.php" method="get">
    <input name="n" type="text" placeholder="Enter an integer"/>
    <input type="submit" value="GO"/>
    </form>
    <p>Enter an integer N to calculate the Nth fibonacci number.</p>
</body>
</html>